import java.util.*;

public class mainGestionDeTorneo {
    public static void main(String[] args) {
        Torneo torneo = new Torneo();

        // Creamos algunos equipos y los agregamos al torneo
        Equipo equipo1 = new Equipo("Juan", "Equipo A", 11);
        Equipo equipo2 = new Equipo("María", "Equipo B", 9);

        torneo.agregarEquipo(equipo1);
        torneo.agregarEquipo(equipo2);

        // Mostramos los equipos participantes
        torneo.mostrarEquipos();
    }
}
