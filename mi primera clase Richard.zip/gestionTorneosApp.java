import java.util.*;

// Clase principal para la gestión de torneos
public class gestionTorneosApp {

    // Clase para representar una actividad (curso, torneo, etc.)
    static class actividad {
        String nombre;
        String descripcion;
        int horas;
        double costo;
        double cuota;
        int maxParticipantes;
        int minParticipantes;

// Agregar otros atributos necesarios

        public actividad(String nombre, String descripcion, int horas, double costo, double cuota,
                         int maxParticipantes, int minParticipantes) {
            this.nombre = nombre;
            this.descripcion = descripcion;
            this.horas = horas;
            this.costo = costo;
            this.cuota = cuota;
            this.maxParticipantes = maxParticipantes;
            this.minParticipantes = minParticipantes;
        }
         // Métodos para la gestión de participantes, monitores, préstamos, etc.
    }

     // Clase para representar un torneo
    static class torneo extends actividad {
         // Agregar atributos específicos de torneo

        public torneo(String nombre, String descripcion, int horas, double costo, double cuota,
                      int maxParticipantes, int minParticipantes) {
            super(nombre, descripcion, horas, costo, cuota, maxParticipantes, minParticipantes);
        }
        // Métodos específicos de torneo
    }

     // Clase para representar un participante
    static class participante {
         // Agregar otros atributos necesarios
        String nombre;

        public participante(String nombre) {
            this.nombre = nombre;
        }
    }

    // Clase para la gestión de torneos
    static class gestionTorneos {
        List<actividad> actividades;
        List<participante> participantes;
        // Agregar otras listas y atributos necesarios

        public gestionTorneos() {
            this.actividades = new ArrayList<>();
            this.participantes = new ArrayList<>();
        }

        public void agregarActividad(actividad actividad) {
            actividades.add(actividad);
        }

        public void agregarParticipante(participante participante) {
            participantes.add(participante);
        }

        // Agregar otros métodos según sea necesario
    }

    public static void main(String[] args) {
        gestionTorneos gestionTorneos = new gestionTorneos();

        // Agregar torneos y participantes
        actividad torneoFutbol = new torneo("Torneo de Fútbol", "Descripción del torneo", 10, 100.0, 10.0, 20, 5);
        gestionTorneos.agregarActividad(torneoFutbol);

        participante participante1 = new participante("Juan");
        gestionTorneos.agregarParticipante(participante1);

        // Realizar otras operaciones según sea necesario

        // Imprimir algún resultado para que la instancia no sea considerada no utilizada
        System.out.println("Número de actividades: " + gestionTorneos.actividades.size());
        System.out.println("Número de participantes: " + gestionTorneos.participantes.size());
    }
}
