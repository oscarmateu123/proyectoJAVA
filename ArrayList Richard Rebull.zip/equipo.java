import java.util.*;

class equipo extends persona {
    private String nombreEquipo;
    private int numIntegrantes;

    public Equipo(String nombre, String nombreEquipo, int numIntegrantes) {
        super(nombre);
        this.nombreEquipo = nombreEquipo;
        this.numIntegrantes = numIntegrantes;
    }

    public String getNombreEquipo() {
        return nombreEquipo;
    }

    public void setNombreEquipo(String nombreEquipo) {
        this.nombreEquipo = nombreEquipo;
    }

    public int getNumIntegrantes() {
        return numIntegrantes;
    }

    public void setNumIntegrantes(int numIntegrantes) {
        this.numIntegrantes = numIntegrantes;
    }

    @Override
    public String toString() {
        return "Equipo: " + nombreEquipo + ", Responsable: " + getNombre() + ", Número de integrantes: " + numIntegrantes;
    }
}
