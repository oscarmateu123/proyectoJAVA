import java.util.*;

class Torneo {
    private ArrayList<Equipo> equipos;

    public Torneo() {
        equipos = new ArrayList<>();
    }

    public void agregarEquipo(Equipo equipo) {
        equipos.add(equipo);
    }

    public void mostrarEquipos() {
        for (Equipo equipo : equipos) {
            System.out.println(equipo);
        }
    }
}